#!/bin/bash

cd descs/
ls -1 *.desc > desc.all
