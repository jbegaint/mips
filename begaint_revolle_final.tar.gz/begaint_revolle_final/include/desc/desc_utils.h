#ifndef _DESC_UTILS_H_
#define _DESC_UTILS_H_

int load_desc_so(char*, DESC*);
void display_desc(DESC);
void display_desc_array();
void load_function(void*, void**, char*);

#endif