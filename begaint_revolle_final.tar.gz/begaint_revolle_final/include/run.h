#ifndef _RUN_H_
#define _RUN_H_

#include "arch/arch.h"

void run(ARCH, int);

#endif