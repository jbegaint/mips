#ifndef _REGISTER_H_
#define _REGISTER_H_

#include "arch.h"

void display_reg(ARCH, int);
void display_reg_all(ARCH);

#endif