#ifndef _SECTION_H_
#define _SECTION_H_

int get_section(ARCH, uint);
int get_offset(ARCH, uint, int);

#endif
